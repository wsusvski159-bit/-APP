package com.gongkan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.HttpAuthHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://gong-kan-1-2.onrender.com/";
    private static final String AUTH_HOST = "gong-kan-1-2.onrender.com";
    private static final String AUTH_USER = "xiaoyu";
    private static final int FILE_CHOOSER_REQUEST = 7041;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean triedSavedCredential = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247, 243, 233));

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        progressParams.gravity = Gravity.CENTER;
        progressBar.setLayoutParams(progressParams);

        root.addView(webView);
        root.addView(progressBar);
        setContentView(root);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePath;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                startActivityForResult(Intent.createChooser(intent, "选择要共看的视频"), FILE_CHOOSER_REQUEST);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (AUTH_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                Intent external = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(external);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedHttpAuthRequest(
                    WebView view,
                    HttpAuthHandler handler,
                    String host,
                    String realm) {
                if (!AUTH_HOST.equalsIgnoreCase(host)) {
                    handler.cancel();
                    return;
                }

                String saved = SecurePasswordStore.load(MainActivity.this);
                if (saved != null && !saved.isEmpty() && !triedSavedCredential) {
                    triedSavedCredential = true;
                    handler.proceed(AUTH_USER, saved);
                    return;
                }

                // 如果保存的密码已经失效，第二次挑战时清掉并重新询问。
                if (triedSavedCredential && saved != null) {
                    SecurePasswordStore.clear(MainActivity.this);
                }
                triedSavedCredential = false;
                showPasswordDialog(handler);
            }
        });

        webView.loadUrl(HOME_URL);
    }

    private void showPasswordDialog(HttpAuthHandler handler) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(24);
        box.setPadding(pad, dp(8), pad, 0);

        TextView hint = new TextView(this);
        hint.setText("输入共看网页密码。用户名已固定为 xiaoyu。\n勾选后会加密保存在本机。\n");
        hint.setTextSize(14f);
        box.addView(hint);

        EditText password = new EditText(this);
        password.setHint("网页密码");
        password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(password, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        CheckBox remember = new CheckBox(this);
        remember.setText("记住密码");
        remember.setChecked(true);
        box.addView(remember);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("共看登录")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("取消", (d, which) -> handler.cancel())
                .setPositiveButton("进入", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p = password.getText().toString();
            if (p.isEmpty()) {
                password.setError("请输入密码");
                return;
            }
            if (remember.isChecked()) {
                SecurePasswordStore.save(MainActivity.this, p);
            } else {
                SecurePasswordStore.clear(MainActivity.this);
            }
            triedSavedCredential = true;
            handler.proceed(AUTH_USER, p);
            dialog.dismiss();
        }));
        dialog.show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /** 用 Android Keystore 加密保存网页密码，不把密码写进 APK。 */
    static class SecurePasswordStore {
        private static final String PREF = "gongkan_secure";
        private static final String KEY_ALIAS = "gongkan_web_password_key";
        private static final String P_CIPHER = "cipher";
        private static final String P_IV = "iv";

        static void save(Activity context, String value) {
            try {
                SecretKey key = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key);
                byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
                context.getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putString(P_CIPHER, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                        .putString(P_IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                        .apply();
            } catch (Exception ignored) {
                Toast.makeText(context, "密码未保存，下次会重新询问", Toast.LENGTH_SHORT).show();
            }
        }

        static String load(Activity context) {
            try {
                String enc = context.getSharedPreferences(PREF, MODE_PRIVATE).getString(P_CIPHER, null);
                String iv = context.getSharedPreferences(PREF, MODE_PRIVATE).getString(P_IV, null);
                if (enc == null || iv == null) return null;
                SecretKey key = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, key,
                        new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
                byte[] plain = cipher.doFinal(Base64.decode(enc, Base64.NO_WRAP));
                return new String(plain, StandardCharsets.UTF_8);
            } catch (Exception e) {
                clear(context);
                return null;
            }
        }

        static void clear(Activity context) {
            context.getSharedPreferences(PREF, MODE_PRIVATE).edit().clear().apply();
        }

        private static SecretKey getOrCreateKey() throws Exception {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(KEY_ALIAS)) {
                return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
            }
            KeyGenerator generator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build());
            return generator.generateKey();
        }
    }
}
