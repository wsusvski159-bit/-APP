共看公开版 Android v1.2（一次设置，自动登录）

更新内容：
1. 第一次打开填写服务地址、用户名、网页密码。
2. 网页密码使用 Android Keystore + AES/GCM 加密后保存在本机。
3. 后续打开 App 自动登录，不再反复询问密码。
4. 右上角“⚙”仍可随时更换服务地址、用户名或密码。
5. 若服务端网页密码发生变化，App 会提示重新设置，而不是一直弹登录框。

GitHub Actions 使用方式：
把本压缩包以文件名 gongkan-public-source.zip 上传并覆盖仓库根目录的同名文件。
原有 .github/workflows/build-gongkan-public.yml 不用修改。
提交后等待 Actions 重新构建 APK。
