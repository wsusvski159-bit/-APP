package com.gongkan.share;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.HttpAuthHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7041;
    private static final String PREF = "gongkan_public_settings";
    private static final String P_URL = "server_url";
    private static final String P_USER = "username";

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;
    private long lastSavedAuthAttemptAt = 0L;
    private String homeUrl = "";
    private String authHost = "";
    private String authUser = "gongkan";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247, 243, 233));

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        progressParams.gravity = Gravity.CENTER;
        progressBar.setLayoutParams(progressParams);

        TextView settings = new TextView(this);
        settings.setText("⚙");
        settings.setTextSize(22f);
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(dp(12), dp(8), dp(12), dp(8));
        settings.setContentDescription("共看设置");
        settings.setOnClickListener(v -> showServerDialog(false));
        FrameLayout.LayoutParams settingsParams = new FrameLayout.LayoutParams(dp(52), dp(48));
        settingsParams.gravity = Gravity.TOP | Gravity.END;
        settingsParams.setMargins(0, dp(8), dp(8), 0);

        root.addView(webView);
        root.addView(progressBar);
        root.addView(settings, settingsParams);
        setContentView(root);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePath,
                                             FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                startActivityForResult(Intent.createChooser(intent, "选择要分析的视频"), FILE_CHOOSER_REQUEST);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (authHost != null && authHost.equalsIgnoreCase(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                // 页面成功加载后重置认证失败探测。
                // 正确保存的密码以后会一直自动用于 HTTP Basic 登录，不再反复弹窗。
                lastSavedAuthAttemptAt = 0L;
            }

            @Override
            public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler,
                                                  String host, String realm) {
                if (authHost == null || !authHost.equalsIgnoreCase(host)) {
                    handler.cancel();
                    return;
                }

                String saved = SecurePasswordStore.load(MainActivity.this);
                if (saved == null || saved.isEmpty()) {
                    handler.cancel();
                    Toast.makeText(MainActivity.this,
                            "还没有保存网页密码，请先完成一次设置", Toast.LENGTH_SHORT).show();
                    showServerDialog(false);
                    return;
                }

                long now = System.currentTimeMillis();
                // 如果刚刚已经用保存的密码尝试过，服务器又立刻再次挑战，
                // 基本可以判断密码已经失效。此时才清除旧密码并要求重新设置。
                if (lastSavedAuthAttemptAt > 0L && now - lastSavedAuthAttemptAt < 4000L) {
                    handler.cancel();
                    SecurePasswordStore.clear(MainActivity.this);
                    lastSavedAuthAttemptAt = 0L;
                    Toast.makeText(MainActivity.this,
                            "网页密码可能已更改，请重新设置一次", Toast.LENGTH_SHORT).show();
                    showServerDialog(false);
                    return;
                }

                lastSavedAuthAttemptAt = now;
                handler.proceed(authUser, saved);
            }
        });

        loadSettings();
        String savedPassword = SecurePasswordStore.load(this);
        if (homeUrl.isEmpty() || savedPassword == null || savedPassword.isEmpty()) {
            showServerDialog(true);
        } else {
            webView.loadUrl(homeUrl);
        }
    }

    private void loadSettings() {
        homeUrl = getSharedPreferences(PREF, MODE_PRIVATE).getString(P_URL, "");
        authUser = getSharedPreferences(PREF, MODE_PRIVATE).getString(P_USER, "gongkan");
        if (homeUrl == null) homeUrl = "";
        if (authUser == null || authUser.trim().isEmpty()) authUser = "gongkan";
        Uri u = Uri.parse(homeUrl);
        authHost = u.getHost() == null ? "" : u.getHost();
    }

    private void showServerDialog(boolean firstRun) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(24);
        box.setPadding(pad, dp(8), pad, 0);

        TextView hint = new TextView(this);
        hint.setText(firstRun
                ? "第一次只需要设置一次。以后打开共看会自动登录，不会反复询问密码。\n"
                : "这里用于更换服务地址、用户名或密码。密码不修改时可以留空。\n");
        hint.setTextSize(14f);
        box.addView(hint);

        EditText url = new EditText(this);
        url.setHint("https://你的服务地址.onrender.com/");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(homeUrl);
        box.addView(url);

        EditText user = new EditText(this);
        user.setHint("网页用户名，例如 gongkan");
        user.setSingleLine(true);
        user.setText(authUser);
        box.addView(user);

        EditText password = new EditText(this);
        password.setHint(firstRun ? "网页密码（仅首次设置）" : "新网页密码（不修改可留空）");
        password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(password);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(firstRun ? "设置共看" : "共看设置")
                .setView(box)
                .setCancelable(!firstRun)
                .setNegativeButton(firstRun ? "退出" : "取消", (d, which) -> {
                    if (firstRun) finish();
                })
                .setPositiveButton("保存并打开", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            String username = user.getText().toString().trim();
            String p = password.getText().toString();
            if (!u.startsWith("https://")) {
                url.setError("请填写 https:// 开头的服务地址");
                return;
            }
            Uri parsed = Uri.parse(u);
            if (parsed.getHost() == null || parsed.getHost().trim().isEmpty()) {
                url.setError("服务地址不正确");
                return;
            }
            if (username.isEmpty()) username = "gongkan";
            if (!u.endsWith("/")) u += "/";

            if (firstRun && p.isEmpty()) {
                password.setError("第一次设置需要填写网页密码");
                return;
            }

            getSharedPreferences(PREF, MODE_PRIVATE).edit()
                    .putString(P_URL, u)
                    .putString(P_USER, username)
                    .apply();

            // 密码使用 Android Keystore + AES/GCM 加密后只保存在本机。
            // 后续启动直接自动登录；只有用户主动改密码或服务端密码失效时才需要再次输入。
            if (!p.isEmpty()) SecurePasswordStore.save(MainActivity.this, p);

            homeUrl = u;
            authHost = parsed.getHost();
            authUser = username;
            lastSavedAuthAttemptAt = 0L;
            dialog.dismiss();
            webView.clearCache(false);
            webView.loadUrl(homeUrl);
        }));
        dialog.show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    static class SecurePasswordStore {
        private static final String KEY_ALIAS = "gongkan_public_web_password_key";
        private static final String P_CIPHER = "cipher";
        private static final String P_IV = "iv";

        static void save(Activity context, String value) {
            try {
                SecretKey key = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key);
                byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
                context.getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putString(P_CIPHER, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                        .putString(P_IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                        .apply();
            } catch (Exception ignored) {
                Toast.makeText(context, "密码未保存，下次会重新询问", Toast.LENGTH_SHORT).show();
            }
        }

        static String load(Activity context) {
            try {
                String enc = context.getSharedPreferences(PREF, MODE_PRIVATE).getString(P_CIPHER, null);
                String iv = context.getSharedPreferences(PREF, MODE_PRIVATE).getString(P_IV, null);
                if (enc == null || iv == null) return null;
                SecretKey key = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, key,
                        new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
                byte[] plain = cipher.doFinal(Base64.decode(enc, Base64.NO_WRAP));
                return new String(plain, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return null;
            }
        }

        static void clear(Activity context) {
            context.getSharedPreferences(PREF, MODE_PRIVATE).edit()
                    .remove(P_CIPHER).remove(P_IV).apply();
        }

        private static SecretKey getOrCreateKey() throws Exception {
            KeyStore store = KeyStore.getInstance("AndroidKeyStore");
            store.load(null);
            if (store.containsAlias(KEY_ALIAS)) {
                return ((KeyStore.SecretKeyEntry) store.getEntry(KEY_ALIAS, null)).getSecretKey();
            }
            KeyGenerator generator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build());
            return generator.generateKey();
        }
    }
}
