package com.gongkan.share;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7041;
    private static final int NOTIFY_PERMISSION_REQUEST = 7042;
    private static final String PREF = "gongkan_public_settings_v18";
    private static final String P_URL = "server_url";
    private static final String P_NOTIFY = "notify_done";
    private static final String CHANNEL_ID = "gongkan_done";

    private WebView webView;
    private FrameLayout splash;
    private TextView splashStatus;
    private ValueCallback<Uri[]> filePathCallback;
    private String homeUrl = "";
    private String homeHost = "";
    private volatile boolean wakeCancelled = false;
    private volatile Uri pendingSharedVideo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        captureShareIntent(getIntent());

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(248, 244, 233));

        webView = new WebView(this);
        webView.setVisibility(View.INVISIBLE);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView settings = new TextView(this);
        settings.setText("⚙");
        settings.setTextSize(22f);
        settings.setTextColor(Color.rgb(77, 96, 83));
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(dp(12), dp(8), dp(12), dp(8));
        settings.setContentDescription("共看连接设置");
        settings.setOnClickListener(v -> showServerDialog(false));
        FrameLayout.LayoutParams settingsParams = new FrameLayout.LayoutParams(dp(52), dp(48));
        settingsParams.gravity = Gravity.TOP | Gravity.END;
        settingsParams.setMargins(0, dp(8), dp(8), 0);

        splash = buildSplash();
        root.addView(webView);
        root.addView(splash);
        root.addView(settings, settingsParams);
        setContentView(root);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new AndroidBridge(), "GongKanAndroid");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePath,
                                             FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                startActivityForResult(Intent.createChooser(intent, "选择要分析的视频"), FILE_CHOOSER_REQUEST);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (homeHost != null && homeHost.equalsIgnoreCase(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                showSplash("共看正在打开…");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                webView.setVisibility(View.VISIBLE);
                splash.setVisibility(View.GONE);
            }
        });

        loadSettings();
        if (homeUrl.isEmpty()) showServerDialog(true);
        else wakeAndOpen();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureShareIntent(intent);
        if (pendingSharedVideo != null) {
            if (homeUrl.isEmpty()) showServerDialog(true);
            else wakeAndOpen();
        }
    }

    @SuppressWarnings("deprecation")
    private void captureShareIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.getType() != null
                && intent.getType().startsWith("video/")) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) pendingSharedVideo = uri;
        }
    }

    private FrameLayout buildSplash() {
        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Color.rgb(248, 244, 233));
        layer.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(28), dp(28), dp(28));

        ImageView icon = new ImageView(this);
        icon.setImageResource(com.gongkan.share.R.mipmap.ic_launcher);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(94), dp(94));
        iconParams.bottomMargin = dp(20);
        box.addView(icon, iconParams);

        TextView title = new TextView(this);
        title.setText("共看");
        title.setTextSize(38f);
        title.setTextColor(Color.rgb(31, 59, 47));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("正在准备视频分析服务");
        sub.setTextSize(16f);
        sub.setTextColor(Color.rgb(98, 113, 103));
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subParams.topMargin = dp(8);
        box.addView(sub, subParams);

        ProgressBar spinner = new ProgressBar(this);
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        spinnerParams.topMargin = dp(26);
        box.addView(spinner, spinnerParams);

        splashStatus = new TextView(this);
        splashStatus.setText("免费服务器第一次唤醒可能需要几十秒");
        splashStatus.setTextSize(13f);
        splashStatus.setTextColor(Color.rgb(128, 137, 130));
        splashStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = dp(14);
        box.addView(splashStatus, statusParams);

        FrameLayout.LayoutParams boxParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        boxParams.gravity = Gravity.CENTER;
        layer.addView(box, boxParams);
        return layer;
    }

    private void showSplash(String text) {
        runOnUiThread(() -> {
            if (splashStatus != null && text != null && !text.isEmpty()) splashStatus.setText(text);
            if (splash != null) splash.setVisibility(View.VISIBLE);
            if (webView != null) webView.setVisibility(View.INVISIBLE);
        });
    }

    private void loadSettings() {
        homeUrl = getSharedPreferences(PREF, MODE_PRIVATE).getString(P_URL, "");
        if (homeUrl == null) homeUrl = "";
        Uri u = Uri.parse(homeUrl);
        homeHost = u.getHost() == null ? "" : u.getHost();
    }

    private void showServerDialog(boolean firstRun) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(24);
        box.setPadding(pad, dp(8), pad, 0);

        TextView hint = new TextView(this);
        hint.setText(firstRun
                ? "第一次只填一次服务地址。以后直接打开，不需要用户名或密码。\n"
                : "这里只用于更换你的共看服务地址。称呼和句子请在共看首页的“个性设置”里修改。\n");
        hint.setTextSize(14f);
        box.addView(hint);

        EditText url = new EditText(this);
        url.setHint("https://你的服务地址.onrender.com/");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(homeUrl);
        box.addView(url);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(firstRun ? "连接共看" : "共看连接设置")
                .setView(box)
                .setCancelable(!firstRun)
                .setNegativeButton(firstRun ? "退出" : "取消", (d, which) -> {
                    if (firstRun) finish();
                })
                .setPositiveButton("保存并连接", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            if (!u.startsWith("https://")) {
                url.setError("请填写 https:// 开头的服务地址");
                return;
            }
            Uri parsed = Uri.parse(u);
            if (parsed.getHost() == null || parsed.getHost().trim().isEmpty()) {
                url.setError("服务地址不正确");
                return;
            }
            if (!u.endsWith("/")) u += "/";

            getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(P_URL, u).apply();
            homeUrl = u;
            homeHost = parsed.getHost();
            dialog.dismiss();
            webView.clearCache(false);
            wakeAndOpen();
        }));
        dialog.show();
    }

    private void wakeAndOpen() {
        wakeCancelled = false;
        showSplash("正在唤醒服务…");

        new Thread(() -> {
            int attempt = 0;
            while (!wakeCancelled && attempt < 45) {
                attempt++;
                if (pingHealth(homeUrl)) {
                    Uri share = pendingSharedVideo;
                    if (share != null) {
                        pendingSharedVideo = null;
                        uploadSharedVideo(share);
                    } else {
                        runOnUiThread(() -> {
                            showSplash("服务已醒来，正在打开共看…");
                            webView.loadUrl(homeUrl);
                        });
                    }
                    return;
                }

                int seconds = attempt * 2;
                showSplash(seconds < 10 ? "服务器正在醒来…" : "还在唤醒中，免费服务器有时会慢一点…");
                try {
                    Thread.sleep(2000L);
                } catch (InterruptedException ignored) {
                    return;
                }
            }

            if (!wakeCancelled) {
                runOnUiThread(() -> {
                    showSplash("暂时没连上服务器，可以检查地址后重试");
                    Toast.makeText(MainActivity.this, "共看服务暂时没有响应", Toast.LENGTH_LONG).show();
                    showServerDialog(false);
                });
            }
        }).start();
    }

    private boolean pingHealth(String baseUrl) {
        HttpURLConnection conn = null;
        try {
            String healthUrl = baseUrl.endsWith("/") ? baseUrl + "health" : baseUrl + "/health";
            conn = (HttpURLConnection) new URL(healthUrl).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Cache-Control", "no-cache");
            int code = conn.getResponseCode();
            return code >= 200 && code < 300;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void uploadSharedVideo(Uri uri) {
        HttpURLConnection conn = null;
        try {
            String filename = queryDisplayName(uri);
            long totalBytes = querySize(uri);
            String mime = getContentResolver().getType(uri);
            if (mime == null || mime.isEmpty()) mime = "video/mp4";
            String boundary = "----GongKan" + UUID.randomUUID().toString().replace("-", "");
            String apiUrl = homeUrl + (homeUrl.endsWith("/") ? "api/upload" : "/api/upload");

            showSplash("正在把视频送给共看…");
            conn = (HttpURLConnection) new URL(apiUrl).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(300000);
            conn.setChunkedStreamingMode(64 * 1024);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setRequestProperty("Accept", "application/json");

            try (OutputStream raw = new BufferedOutputStream(conn.getOutputStream());
                 InputStream in = new BufferedInputStream(getContentResolver().openInputStream(uri))) {
                writeUtf8(raw, "--" + boundary + "\r\n");
                writeUtf8(raw, "Content-Disposition: form-data; name=\"video\"; filename=\"" + safeFilename(filename) + "\"\r\n");
                writeUtf8(raw, "Content-Type: " + mime + "\r\n\r\n");

                byte[] buf = new byte[64 * 1024];
                long sent = 0;
                int n;
                while ((n = in.read(buf)) != -1) {
                    raw.write(buf, 0, n);
                    sent += n;
                    if (totalBytes > 0) {
                        int pct = (int) Math.min(99, Math.max(1, sent * 100 / totalBytes));
                        showSplash("正在上传视频 " + pct + "%…");
                    }
                }
                writeUtf8(raw, "\r\n--" + boundary + "--\r\n");
                raw.flush();
            }

            showSplash("视频已送到共看，AI 正在看画面和听声音…");
            int code = conn.getResponseCode();
            String body = readBody(code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream());
            JSONObject json = new JSONObject(body.isEmpty() ? "{}" : body);
            if (code >= 200 && code < 300 && json.optBoolean("ok", false)) {
                String videoId = json.optString("video_id", "");
                showSplash("看完啦，正在打开报告…");
                runOnUiThread(() -> {
                    notifyDoneNative("刚刚分享给共看的视频已经看完了。");
                    if (!videoId.isEmpty()) webView.loadUrl(homeUrl + "report/" + Uri.encode(videoId));
                    else webView.loadUrl(homeUrl);
                });
            } else {
                String detail = json.optString("detail", "视频分析失败");
                throw new RuntimeException(detail);
            }
        } catch (Exception e) {
            final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "共看失败：" + msg, Toast.LENGTH_LONG).show();
                webView.loadUrl(homeUrl);
            });
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void writeUtf8(OutputStream out, String s) throws Exception {
        out.write(s.getBytes(StandardCharsets.UTF_8));
    }

    private String readBody(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String queryDisplayName(Uri uri) {
        String result = "shared-video.mp4";
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) {
                    String v = c.getString(idx);
                    if (v != null && !v.trim().isEmpty()) result = v;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return result;
    }

    private long querySize(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0 && !c.isNull(idx)) return c.getLong(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private String safeFilename(String name) {
        return name.replace("\"", "'").replace("\r", " ").replace("\n", " ");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "共看完成提醒", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("视频分析完成时提醒");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void requestNotifyPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY_PERMISSION_REQUEST);
        }
    }

    private void notifyDoneNative(String message) {
        boolean enabled = getSharedPreferences(PREF, MODE_PRIVATE).getBoolean(P_NOTIFY, false);
        if (!enabled) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        android.app.Notification.Builder builder = new android.app.Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("共看完成")
                .setContentText(message)
                .setAutoCancel(true);
        try {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify((int) (System.currentTimeMillis() & 0xfffffff), builder.build());
        } catch (SecurityException ignored) {}
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void setNotifyEnabled(boolean enabled) {
            getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean(P_NOTIFY, enabled).apply();
        }

        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(() -> requestNotifyPermission());
        }

        @JavascriptInterface
        public void notifyDone(String message) {
            runOnUiThread(() -> notifyDoneNative(message == null || message.isEmpty()
                    ? "视频已经分析完成。" : message));
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        wakeCancelled = true;
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
