package com.gongkan.share;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "gongkan_public_v22";
    private static final String KEY_SERVICE = "service_url";
    private static final String KEY_API = "api_config";
    private static final String KEY_NOTIFY = "notify_enabled";
    private static final String SETUP_URL = "file:///android_asset/setup.html";
    private static final String DEPLOY_URL = "https://render.com/deploy?repo=https%3A%2F%2Fgithub.com%2Fwsusvski159-bit%2F-1.1";
    private static final String HELP_URL = "https://github.com/wsusvski159-bit/-1.1#%E4%B8%80%E6%99%AE%E9%80%9A%E7%94%A8%E6%88%B7%E6%80%8E%E4%B9%88%E5%BC%80%E5%A7%8B";
    private static final String CHANNEL_ID = "gongkan_done";

    private WebView webView;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        createNotificationChannel();
        buildWebView();
        String service = cleanUrl(prefs.getString(KEY_SERVICE, ""));
        if (service.isEmpty()) showSetup(); else loadService(service);
    }

    private void buildWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(248,244,233));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "GongKanAndroid");
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith("https://")) injectSavedApi();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                startActivityForResult(Intent.createChooser(intent, "选择视频"), 9001);
                return true;
            }
        });
    }

    private void injectSavedApi() {
        String api = prefs.getString(KEY_API, "");
        if (api == null || api.trim().isEmpty()) return;
        String quoted = JSONObject.quote(api);
        String js = "try{localStorage.setItem('gongkan_api_v19'," + quoted + ");" +
                "if(typeof loadApiCfg==='function'){apiCfg=loadApiCfg();}" +
                "if(typeof updateApiBadge==='function'){updateApiBadge();}}catch(e){}";
        webView.evaluateJavascript(js, null);
    }

    private void showSetup() {
        runOnUiThread(() -> webView.loadUrl(SETUP_URL));
    }

    private void loadService(String service) {
        String clean = cleanUrl(service);
        if (clean.isEmpty()) { showSetup(); return; }
        runOnUiThread(() -> webView.loadUrl(clean + "/"));
    }

    private String cleanUrl(String raw) {
        if (raw == null) return "";
        String v = raw.trim();
        while (v.endsWith("/")) v = v.substring(0, v.length()-1);
        return v;
    }

    private void checkServiceAsync(String raw) {
        final String service = cleanUrl(raw);
        io.execute(() -> {
            boolean ok = false;
            String msg;
            HttpURLConnection c = null;
            try {
                if (!service.startsWith("https://")) throw new Exception("地址必须以 https:// 开头");
                URL u = new URL(service + "/health");
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(65000);
                c.setReadTimeout(65000);
                c.setRequestMethod("GET");
                c.setUseCaches(false);
                int code = c.getResponseCode();
                if (code >= 200 && code < 300) {
                    ok = true;
                    msg = "服务已经连接，可以继续下一步。";
                } else msg = "服务返回 HTTP " + code + "，请确认地址是不是自己的 Render 服务。";
            } catch (Exception e) {
                msg = "没有连上：" + (e.getMessage() == null ? "请稍后再试" : e.getMessage());
            } finally { if (c != null) c.disconnect(); }
            final boolean fok = ok; final String fmsg = msg;
            runOnUiThread(() -> webView.evaluateJavascript("window.onServiceChecked(" + (fok?"true":"false") + "," + JSONObject.quote(fmsg) + "," + JSONObject.quote(service) + ")", null));
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "共看完成提醒", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    private void postDoneNotification(String title, String body) {
        if (!prefs.getBoolean(KEY_NOTIFY, false)) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(this, CHANNEL_ID)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title == null || title.isEmpty() ? "共看看完啦" : title)
                .setContentText(body == null ? "可以回来看看报告了。" : body)
                .setAutoCancel(true)
                .setContentIntent(pi);
        ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(2202, b.build());
    }

    public class AndroidBridge {
        @JavascriptInterface public String getSetupState() {
            try {
                JSONObject o = new JSONObject();
                o.put("service_url", prefs.getString(KEY_SERVICE, ""));
                String api = prefs.getString(KEY_API, "");
                if (api != null && !api.trim().isEmpty()) o.put("api", new JSONObject(api));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void openRenderDeploy() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DEPLOY_URL))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "打不开浏览器", Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface public void openHelp() {
            runOnUiThread(() -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(HELP_URL))));
        }

        @JavascriptInterface public void checkService(String url) { checkServiceAsync(url); }

        @JavascriptInterface public void saveAndOpen(String serviceUrl, String apiJson) {
            String clean = cleanUrl(serviceUrl);
            if (!clean.startsWith("https://")) return;
            prefs.edit().putString(KEY_SERVICE, clean).putString(KEY_API, apiJson == null ? "" : apiJson).apply();
            loadService(clean);
        }

        @JavascriptInterface public void saveApiConfig(String json) {
            prefs.edit().putString(KEY_API, json == null ? "" : json).apply();
        }

        @JavascriptInterface public void openConnectionSettings() { showSetup(); }

        @JavascriptInterface public void setNotifyEnabled(boolean enabled) { prefs.edit().putBoolean(KEY_NOTIFY, enabled).apply(); }

        @JavascriptInterface public void requestNotifications() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2202));
            }
        }

        @JavascriptInterface public void notifyDone(String title, String body) { runOnUiThread(() -> postDoneNotification(title, body)); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9001 && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack() && !SETUP_URL.equals(webView.getUrl())) webView.goBack();
        else if (webView != null && webView.getUrl() != null && webView.getUrl().startsWith("https://")) super.onBackPressed();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
